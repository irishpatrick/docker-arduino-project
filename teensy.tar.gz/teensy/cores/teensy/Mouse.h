// empty Mouse.h file, for compability with Arduino's Mouse examples
