namespace ssd1351 {

struct NoBuffer {};
struct SingleBuffer {};
struct DoubleBuffer {};

}
